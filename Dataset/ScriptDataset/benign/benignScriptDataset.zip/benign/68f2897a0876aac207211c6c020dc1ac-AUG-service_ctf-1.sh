    if [ -f $CTF_SWITCH ]; then
        echo 1 > $CTF_SWITCH
    fi
