#!/bin/sh
echo [$0] ... > /dev/console
brctl showmacs br0
