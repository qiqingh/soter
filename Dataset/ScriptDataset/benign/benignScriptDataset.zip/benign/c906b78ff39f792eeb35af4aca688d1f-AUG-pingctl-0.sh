	rgdb -A /etc/templates/pingctl.php
	sh /var/run/__pingctl.sh

