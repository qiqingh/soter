    [ "$DEBUG_SETTING" = "1" ] && $@
