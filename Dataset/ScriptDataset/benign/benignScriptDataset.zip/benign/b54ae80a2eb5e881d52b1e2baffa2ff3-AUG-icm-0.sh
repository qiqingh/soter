#
# Copyright (c) 2014 Qualcomm Atheros, Inc.
#
# All Rights Reserved.
# Qualcomm Atheros Confidential and Proprietary.
#

. /etc/functions.sh
. /lib/functions/service.sh

SERVICE_NAME=icm
SERVICE_MATCH_EXEC=1
SERVICE_DAEMONIZE=1

