	echo "Failed to verify Firmware MD5"
	exit 1
