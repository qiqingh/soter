        printf "<tr>\n<td>%s</td><td>%d</td>\n</tr>", $1, $2;
