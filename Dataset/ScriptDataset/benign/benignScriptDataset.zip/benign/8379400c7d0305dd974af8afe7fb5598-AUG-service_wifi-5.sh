	ulog wlan status "${SERVICE_NAME}, service_restart()"
	service_stop
	service_start
