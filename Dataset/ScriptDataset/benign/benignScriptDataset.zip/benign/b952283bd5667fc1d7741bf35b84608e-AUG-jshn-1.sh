	# dest=$1
	# var=$2
	eval "$1=\"\$${JSON_PREFIX}$2\""
