   ip link set vlan$1 down
   vconfig rem vlan$1
