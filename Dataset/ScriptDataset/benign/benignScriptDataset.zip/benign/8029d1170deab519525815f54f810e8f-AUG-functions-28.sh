	grep -qs "^${1}:" ${IPKG_INSTROOT}/etc/passwd
