	echo "blink_off" > /proc/bdutil/leds
	echo "on"        > /proc/bdutil/leds
