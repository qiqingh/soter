#   echo "[utopia][registration] $SELF_NAME unregistering from sysevent"
   sm_unregister $SERVICE_NAME
