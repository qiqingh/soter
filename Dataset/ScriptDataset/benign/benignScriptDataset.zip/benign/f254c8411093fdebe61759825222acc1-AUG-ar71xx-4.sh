	ar71xx_get_mtd_offset_size_format EEPROM 4118 2 %02x
