	config_add_array basic_rate
	config_add_array supported_rates

	config_add_string country
	config_add_boolean country_ie doth
	config_add_string require_mode
	config_add_boolean legacy_rates

	config_add_string acs_chan_bias
	config_add_array hostapd_options

	hostapd_add_log_config
