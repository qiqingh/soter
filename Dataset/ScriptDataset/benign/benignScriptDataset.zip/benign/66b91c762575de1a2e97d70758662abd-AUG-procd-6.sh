	while [ "$#" -gt 0 ]; do
		json_add_string "" "$1"
		shift
	done
