	ulog wlan status "${SERVICE_NAME}, wifi_virtual_onetime_setting"
