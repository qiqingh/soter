        echo 8 >/sys/class/gpio/export
        echo in >/sys/class/gpio/gpio8/direction
	turn_USB "on"
        sleep 10
