   parse_wan_namespace_sysevent $1
   wan_info_by_namespace $NAMESPACE
