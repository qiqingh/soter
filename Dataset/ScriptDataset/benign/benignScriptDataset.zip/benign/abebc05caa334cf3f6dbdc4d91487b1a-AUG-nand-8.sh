	identify_magic $(get_magic_long_tar "$1" "$2")
