	ucidef_set_interface "lan" ifname "$1" protocol "${2:-static}"
