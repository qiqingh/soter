	echo -n dd skip=32 iflag=skip_bytes
