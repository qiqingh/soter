	grep -qE "system type.*: (VR9|xRX200)" /proc/cpuinfo
