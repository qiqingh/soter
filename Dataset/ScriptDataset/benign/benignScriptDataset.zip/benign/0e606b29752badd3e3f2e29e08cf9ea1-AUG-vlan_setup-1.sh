    echo "Usage:"
    echo "  $0 3 LLLLW - config Ralink RT6855/MT7620/MT7621 ESW with VLAN and WAN at port 4"
    echo "  $0 4 0 - restore MT7530 to no VLAN partition"
    exit 0
