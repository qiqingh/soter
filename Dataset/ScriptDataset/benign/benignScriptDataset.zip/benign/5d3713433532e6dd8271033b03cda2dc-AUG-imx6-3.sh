	blkid | grep $(rootpartuuid)-01 | cut -d : -f1
