	hostapd_noscan=1
