    log "stop timezone service"
    remove_cron_rules
