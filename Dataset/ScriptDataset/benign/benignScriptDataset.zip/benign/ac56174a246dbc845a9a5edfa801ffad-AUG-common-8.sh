	[ "$VERBOSE" -ge 1 ] && echo "$@"
