   prepare_udevd_conf
   /sbin/udevadm control --reload-rules
