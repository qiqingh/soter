	ulog wlan status "${SERVICE_NAME}, wifi_renew_clients_handler()"
	echo "${SERVICE_NAME}, wifi_renew_clients_handler()"
	wifi_refresh_interfaces
