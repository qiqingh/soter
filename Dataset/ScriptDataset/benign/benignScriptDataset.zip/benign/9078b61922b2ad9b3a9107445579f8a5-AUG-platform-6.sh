	. /etc/diag.sh; set_state upgrade
