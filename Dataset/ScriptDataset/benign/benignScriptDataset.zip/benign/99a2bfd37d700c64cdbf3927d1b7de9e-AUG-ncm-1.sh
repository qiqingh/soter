	. /lib/functions.sh
	. ../netifd-proto.sh
	init_proto "$@"
