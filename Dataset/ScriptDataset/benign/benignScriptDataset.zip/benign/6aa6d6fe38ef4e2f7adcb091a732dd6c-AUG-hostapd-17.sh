	killall hostapd wpa_supplicant meshd-nl80211
