	ucidef_set_interface "wan" ifname "$1" protocol "${2:-dhcp}"
