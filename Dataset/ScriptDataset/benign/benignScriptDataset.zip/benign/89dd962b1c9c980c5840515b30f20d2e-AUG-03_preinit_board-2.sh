	. /lib/functions/lantiq.sh

	lantiq_board_detect
