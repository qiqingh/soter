	_config_add_generic 3 "$@"
