    if [ -z "$SYSCFG_hardware_vendor_name" ]; then
        SYSCFG_hardware_vendor_name=`syscfg get hardware_vendor_name`
    fi
