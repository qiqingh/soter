	config_add_string "$@"
