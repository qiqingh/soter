	echo "blink_off" > /proc/bdutil/leds
	echo "off"       > /proc/bdutil/leds
