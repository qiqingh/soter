	local interface="$1"
	proto_kill_command "$interface"
