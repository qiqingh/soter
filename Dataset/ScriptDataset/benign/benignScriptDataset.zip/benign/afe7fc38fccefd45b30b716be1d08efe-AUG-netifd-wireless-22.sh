	config_add_string mode ssid encryption 'key:wpakey'
