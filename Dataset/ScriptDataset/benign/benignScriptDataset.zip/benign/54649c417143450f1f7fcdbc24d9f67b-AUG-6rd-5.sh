	no_device=1
	available=1

	proto_config_add_int "mtu"
	proto_config_add_boolean "df"
	proto_config_add_int "ttl"
	proto_config_add_string "tos"
	proto_config_add_string "ipaddr"
	proto_config_add_string "peeraddr"
	proto_config_add_string "ip6prefix"
	proto_config_add_string "ip6prefixlen"
	proto_config_add_string "ip4prefixlen"
	proto_config_add_string "tunlink"
	proto_config_add_string "zone"
