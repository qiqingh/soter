#!/bin/sh

boot_hook_add preinit_main do_lantiq
