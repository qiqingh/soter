	set_driver_pspretend_threadhold $1
