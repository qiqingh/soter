	config_cb() { return 0; }
	option_cb() { return 0; }
	list_cb() { return 0; }
