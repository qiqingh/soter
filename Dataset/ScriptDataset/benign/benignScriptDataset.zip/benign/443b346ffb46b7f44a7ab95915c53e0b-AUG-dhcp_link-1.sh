    [ "$BRIDGE_DEBUG_SETTING" = "1" ] && $@
