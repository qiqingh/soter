    region=$1
    eval echo "$`echo ${region}_CH_LIST_5G`"
