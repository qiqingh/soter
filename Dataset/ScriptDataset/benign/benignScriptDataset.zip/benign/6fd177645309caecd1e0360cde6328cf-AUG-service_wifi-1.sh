    [ "$WIFI_DEBUG_SETTING" = "1" ] && $@
