	__network_ifstatus "$1" "$2" "['ipv4-address'][0].address";
