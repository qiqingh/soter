	_procd_open_instance
	_procd_set_param command "$@"
	_procd_close_instance
