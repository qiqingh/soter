	_json_add_table "$1" array A
