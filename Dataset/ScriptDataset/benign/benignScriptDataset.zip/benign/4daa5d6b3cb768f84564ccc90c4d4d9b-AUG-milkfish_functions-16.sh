    wget -O - http://firewalltest.milkfish.org/embedded_tcpscan
