  echo `syscfg get user_auth_enc`
