	ar71xx_get_mtd_offset_size_format EEPROM 12 2 %02x
