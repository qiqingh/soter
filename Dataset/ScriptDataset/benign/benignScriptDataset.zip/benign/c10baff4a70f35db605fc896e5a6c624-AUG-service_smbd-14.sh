  umount_samba_shares
  rm -f $SAMBA_CONF_FILE
