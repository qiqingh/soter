	config_add_boolean "$@"
