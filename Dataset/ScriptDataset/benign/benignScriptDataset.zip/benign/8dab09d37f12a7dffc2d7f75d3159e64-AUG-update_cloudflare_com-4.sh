	write_log 4 "'rec_edit' failed with error:\n$__MSG"
	return 1
