	echo "wifi, $PHY_IF wps_status_callback TIMEOUT received"
	sysevent set wl_wps_status "false"
