#!/bin/sh


sysconf pptp $*

